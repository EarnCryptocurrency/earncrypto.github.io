<?php

$site_url = "http://example.com"; //Your website link, no slash in ending
                                  //i.e. http://example.com, not http://example.com/
$site_name = "Bitcoin Faucet"; //Your website name

$amount = 50; //satoshi
$faucet_timer = 30; //minutes
$referral = 25; //percent

$api_fh = "xxx"; //FaucetHUB API Key
$api_fs = "xxx"; //FaucetSystem API Key


//short links integration

$extra = 50; //extra satoshi for viewing short link
$prolink_api = "xxx"; //ProLink API Token


//reCaptcha integration

$site_key = "xxx"; //reCaptcha site key
$secret_key = "xxx"; //reCaptcha secret key

$db_name = "xxx"; //don't change this

?>